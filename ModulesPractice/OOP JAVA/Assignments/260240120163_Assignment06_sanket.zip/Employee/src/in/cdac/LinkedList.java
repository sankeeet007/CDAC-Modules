package in.cdac;

public class LinkedList {

    Node start;
    Node end;
    Node current;
    int maxCount;

    // ADD NODE
    public void add(Object data) {
        Node tmpNode = new Node(data);

        if (start == null) {
            start = end = current = tmpNode;
        } else {
            end.next = tmpNode;
            tmpNode.previous = end;
            end = tmpNode;
        }
        maxCount++;
    }

    // DELETE NODE
    public void delete(int index) {
        if (start == null || index < 0 || index >= maxCount) {
            return;
        }

        if (start == end) {
            start = end = current = null;
        } 
        else if (index == 0) {
            start = start.next;
            start.previous = null;
        } 
        else if (index == maxCount - 1) {
            end = end.previous;
            end.next = null;
        } 
        else {
            Node tmpNode = start;

            for (int i = 0; i < index; i++) {
                tmpNode = tmpNode.next;
            }

            tmpNode.previous.next = tmpNode.next;
            tmpNode.next.previous = tmpNode.previous;
        }
        maxCount--;
    }

    // Get First
    public Object getFirst() {
        if (start == null) return null;
        current = start;
        return current.data;
    }

    // Get Last
    public Object getLast() {
        if (end == null) return null;
        current = end;
        return current.data;
    }

    // Get Next Node
    public Object getNext() {
        if (current == null) return null;

        if (current.next == null) {
            current = start; // circular
        } else {
            current = current.next;
        }
        return current.data;
    }

    // Get Previous Node
    public Object getPrevious() {
        if (current == null) return null;

        if (current.previous == null) {
            current = end; // circular
        } else {
            current = current.previous;
        }
        return current.data;
    }

    // Get using Index
    public Object get(int index) {
        if (start == null || index < 0 || index >= maxCount) {
            return null;
        }

        Node tmpNode = start;
        for (int i = 0; i < index; i++) {
            tmpNode = tmpNode.next;
        }
        return tmpNode.data;
    }

    public int getMaxCount() {
        return maxCount;
    }

    public void sortByNameAsc() {
        if (start == null) return;

        for (Node i = start; i != null; i = i.next) {
            for (Node j = i.next; j != null; j = j.next) {
                Employee e1 = (Employee) i.data;
                Employee e2 = (Employee) j.data;
                if (e1.getName().compareToIgnoreCase(e2.getName()) > 0) {
                    Object temp = i.data;
                    i.data = j.data;
                    j.data = temp;
                }
            }
        }
    }
    
    
    public void sortByNameDesc() {
        if (start == null) return;

        for (Node i = start; i != null; i = i.next) {
            for (Node j = i.next; j != null; j = j.next) {
                Employee e1 = (Employee) i.data;
                Employee e2 = (Employee) j.data;
                if (e1.getName().compareToIgnoreCase(e2.getName()) < 0) {
                    Object temp = i.data;
                    i.data = j.data;
                    j.data = temp;
                }
            }
        }
    }
    
    // Rest Pointer
    public void reset() {
        current = start;
    }
}