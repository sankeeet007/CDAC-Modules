/**
 * 
 */
/**
 * 
 */
module Rectangle {
}