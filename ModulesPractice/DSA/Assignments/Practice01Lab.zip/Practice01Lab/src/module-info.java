/**
 * 
 */
/**
 * 
 */
module Practice01Lab {
}