/**
 * 
 */
/**
 * 
 */
module GPTQue01 {
}