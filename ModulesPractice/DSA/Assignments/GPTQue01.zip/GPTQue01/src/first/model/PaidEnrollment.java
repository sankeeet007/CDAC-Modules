package first.model;

import java.time.LocalDate;

public class PaidEnrollment extends Enrollment {

	public PaidEnrollment(int id, String name, CourseType course, LocalDate date, double fee) {
		super(id, name, course, date, fee);
	}

	@Override
	public double calculateFinalFee() {
		if(course == CourseType.CERTIFICATION)
			return fee + 500;
		return fee;
	}
	
}
