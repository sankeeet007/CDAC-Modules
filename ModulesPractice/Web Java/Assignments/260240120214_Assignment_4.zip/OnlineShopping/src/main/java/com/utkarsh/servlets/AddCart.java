package com.utkarsh.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.utkarsh.cart.Cart;
import com.utkarsh.cart.ShoppingCart;
import com.utkarsh.entity.Products;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebInitParam;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet(initParams = { @WebInitParam(name = "driverClass", value = "com.mysql.cj.jdbc.Driver"),
		@WebInitParam(name = "dbUrl", value = "jdbc:mysql://localhost:3306/cdac"),
		@WebInitParam(name = "dbUser", value = "cdac"),
		@WebInitParam(name = "dbPassword", value = "cdac") }, urlPatterns = { "/AddCart" })
public class AddCart extends HttpServlet {

	private static final long serialVersionUID = 1L;

	private Connection connection;

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);

		String driverClass = config.getInitParameter("driverClass");
		String dbUrl = config.getInitParameter("dbUrl");
		String dbUser = config.getInitParameter("dbUser");
		String dbPassword = config.getInitParameter("dbPassword");

		try {
			Class.forName(driverClass);
			connection = DriverManager.getConnection(dbUrl, dbUser, dbPassword);
		} catch (ClassNotFoundException e) {
			throw new ServletException("Driver not found: " + driverClass, e);
		} catch (SQLException e) {
			throw new ServletException("DB connection failed: " + e.getMessage(), e);
		}
	}

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String productId = request.getParameter("productId");
		String categoryId = request.getParameter("categoryId");
		String price = request.getParameter("price");

		if (productId == null || categoryId == null || price == null) {
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing required parameters.");
			return;
		}

		super.service(request, response);
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession(false);
		if (session == null) {
			response.sendRedirect("login.html");
			return;
		}

		int categoryId = Integer.parseInt(request.getParameter("categoryId"));
		int productId = Integer.parseInt(request.getParameter("productId"));
		float price = Float.parseFloat(request.getParameter("price"));

		Products objProduct = new Products();
		objProduct.setCategoryId(categoryId);
		objProduct.setProductId(productId);
		objProduct.setProductPrice(price);

		Cart objCart = (Cart) session.getAttribute("cart");
		if (objCart == null) {
			objCart = new ShoppingCart();
			session.setAttribute("cart", objCart);
		}

		objCart.addToCart(objProduct);
		response.sendRedirect("ListCart");
	}

	@Override
	public void destroy() {
		if (connection != null) {
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		super.destroy();
	}
}