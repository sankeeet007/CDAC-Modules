package com.utkarsh.cart;

import java.util.Iterator;
import com.utkarsh.entity.Products;

public interface Cart {
    public void addToCart(Products objProduct);
    public Iterator<Products> listCart();
}