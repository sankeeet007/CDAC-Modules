package com.utkarsh.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;

import com.utkarsh.dao.CategoryDAO;
import com.utkarsh.dao.CategoryDAOImpl;
import com.utkarsh.exceptions.CategoryException;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebInitParam;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet(initParams = { @WebInitParam(name = "driverClass", value = "com.mysql.cj.jdbc.Driver"),
		@WebInitParam(name = "dbUrl", value = "jdbc:mysql://localhost:3306/cdac"),
		@WebInitParam(name = "dbUser", value = "cdac"),
		@WebInitParam(name = "dbPassword", value = "cdac") }, urlPatterns = { "/Category" })
public class Category extends HttpServlet {

	private static final long serialVersionUID = 1L;

	private CategoryDAO categoryDAO;

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		try {
			categoryDAO = new CategoryDAOImpl(config);
		} catch (CategoryException e) {
			throw new ServletException("CategoryDAO Failed : " + e.getMessage());
		}
	}

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession(false);

		if (session == null || session.getAttribute("userName") == null) {
			String userNameFromCookie = null;
			String roleFromCookie = null;

			Cookie[] cookies = request.getCookies();
			if (cookies != null) {
				for (Cookie cookie : cookies) {
					if ("userName".equals(cookie.getName())) {
						userNameFromCookie = cookie.getValue();
					}
					if ("role".equals(cookie.getName())) {
						roleFromCookie = cookie.getValue();
					}
				}
			}

			if (userNameFromCookie != null) {
				session = request.getSession(true);
				session.setAttribute("userName", userNameFromCookie);
				session.setAttribute("role", roleFromCookie);
			} else {
				response.sendRedirect("login.html");
				return;
			}
		}

		super.service(request, response);
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession(false);
		String userName = (String) session.getAttribute("userName");

		Iterator<com.utkarsh.entity.Category> iter = categoryDAO.getAllCategories();

		PrintWriter out = response.getWriter();
		out.println("<html>");
		out.println("<body>");
		out.println("<a href='Logout'>Logout</a><br/><br/>");
		out.println("Welcome, <b>" + userName + "</b>");
		out.println("<table border='1'>");
		out.println("<tr>");
		out.println("<th>Name</th>");
		out.println("<th>Description</th>");
		out.println("<th>Image</th>");
		out.println("</tr>");

		while (iter.hasNext()) {
			com.utkarsh.entity.Category objCategory = iter.next();
			out.println("<tr>");
			out.println("<td><a href='Products?categoryId=" + objCategory.getCategoryId() + "'>"
					+ objCategory.getCategoryName() + "</a></td>");
			out.println("<td>" + objCategory.getCategoryDescription() + "</td>");
			out.println("<td><img src='Images/" + objCategory.getCategoryImageUrl()
					+ "' height='80px' width='80px'/></td>");
			out.println("</tr>");
		}

		out.println("</table>");
		out.println("</body>");
		out.println("</html>");
	}

	@Override
	public void destroy() {
		categoryDAO = null;
		super.destroy();
	}
}