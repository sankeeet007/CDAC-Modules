package com.utkarsh.dao;

import java.util.Iterator;
import com.utkarsh.entity.Category;

public interface CategoryDAO {
    public Iterator<Category> getAllCategories();
    public boolean addCategory(Category category);
    public boolean deleteCategory(int categoryId);
}