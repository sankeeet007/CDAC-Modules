package com.utkarsh.servlets;

import java.io.IOException;

import com.utkarsh.dao.UsersDAO;
import com.utkarsh.dao.UsersDAOImpl;
import com.utkarsh.entity.Users;
import com.utkarsh.exceptions.UsersException;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebInitParam;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(initParams = { @WebInitParam(name = "driverClass", value = "com.mysql.cj.jdbc.Driver"),
		@WebInitParam(name = "dbUrl", value = "jdbc:mysql://localhost:3306/cdac"),
		@WebInitParam(name = "dbUser", value = "cdac"),
		@WebInitParam(name = "dbPassword", value = "cdac") }, urlPatterns = { "/register" })
public class Register extends HttpServlet {

	private static final long serialVersionUID = 1L;

	private UsersDAO usersDAO;

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		try {
			usersDAO = new UsersDAOImpl(config);
		} catch (UsersException e) {
			throw new ServletException("UsersDAO init failed: " + e.getMessage());
		}
	}

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		if ("POST".equalsIgnoreCase(request.getMethod())) {
			String userName = request.getParameter("username");
			String password = request.getParameter("password");
			String name = request.getParameter("name");
			String email = request.getParameter("email");
			String city = request.getParameter("city");

			if (userName == null || password == null || name == null || email == null || city == null) {
				response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing required fields.");
				return;
			}
		}

		super.service(request, response);
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.sendRedirect("UserRegistrationForm.html");
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		Users user = new Users();
		user.setUserName(request.getParameter("username"));
		user.setPassword(request.getParameter("password"));
		user.setName(request.getParameter("name"));
		user.setEmail(request.getParameter("email"));
		user.setCity(request.getParameter("city"));

		try {
			boolean status = usersDAO.registerUser(user);
			if (status) {
				response.sendRedirect("login.html");
			} else {
				response.getWriter().println("Registration Failed");
			}
		} catch (Exception e) {
			e.printStackTrace();
			response.getWriter().println("Error : " + e.getMessage());
		}
	}

	@Override
	public void destroy() {
		usersDAO = null;
		super.destroy();
	}
}