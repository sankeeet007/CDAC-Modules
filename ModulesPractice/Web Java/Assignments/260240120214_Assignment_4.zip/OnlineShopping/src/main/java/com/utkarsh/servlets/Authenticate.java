package com.utkarsh.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebInitParam;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet(initParams = { @WebInitParam(name = "driverClass", value = "com.mysql.cj.jdbc.Driver"),
		@WebInitParam(name = "dbUrl", value = "jdbc:mysql://localhost/cdac"),
		@WebInitParam(name = "dbUser", value = "cdac"),
		@WebInitParam(name = "dbPassword", value = "cdac") }, urlPatterns = { "/Authenticate" })
public class Authenticate extends HttpServlet {

	private static final long serialVersionUID = 1L;

	private String dbUrl;
	private String dbUser;
	private String dbPassword;
	private String driverClass;
	private Connection connection;

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);

		driverClass = config.getInitParameter("driverClass");
		dbUrl = config.getInitParameter("dbUrl");
		dbUser = config.getInitParameter("dbUser");
		dbPassword = config.getInitParameter("dbPassword");

		try {
			Class.forName(driverClass);
			connection = DriverManager.getConnection(dbUrl, dbUser, dbPassword);
		} catch (ClassNotFoundException e) {
			throw new ServletException("Driver not found: " + driverClass, e);
		} catch (SQLException e) {
			throw new ServletException("DB connection failed: " + e.getMessage(), e);
		}
	}

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String userName = request.getParameter("userName");
		String password = request.getParameter("password");
		String role = request.getParameter("role");

		if (userName == null || password == null || role == null) {
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing required parameters.");
			return;
		}

		super.service(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		PrintWriter out = response.getWriter();

		String userName = request.getParameter("userName");
		String password = request.getParameter("password");
		String role = request.getParameter("role");

		String table = "admin".equals(role) ? "admins" : "users";
		String query = "SELECT * FROM " + table + " WHERE userName = ? AND password = ?";

		try (PreparedStatement ps = connection.prepareStatement(query)) {

			ps.setString(1, userName);
			ps.setString(2, password);

			try (ResultSet rs = ps.executeQuery()) {
				if (rs.next()) {
					HttpSession session = request.getSession(true);
					session.setAttribute("userName", userName);
					session.setAttribute("role", role);

					Cookie userCookie = new Cookie("userName", userName);
					userCookie.setMaxAge(60 * 60 * 24);
					userCookie.setPath("/");
					response.addCookie(userCookie);

					Cookie roleCookie = new Cookie("role", role);
					roleCookie.setMaxAge(60 * 60 * 24);
					roleCookie.setPath("/");
					response.addCookie(roleCookie);

					if ("admin".equals(role)) {
						response.sendRedirect("AdminDashboard.html");
					} else {
						response.sendRedirect("Category");
					}
				} else {
					response.sendRedirect("login.html");
				}
			}

		} catch (SQLException e) {
			out.println("We seem to have run into an issue, our team is already sleeping over it");
			e.printStackTrace();
		}
	}

	@Override
	public void destroy() {
		if (connection != null) {
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		super.destroy();
	}
}