package com.utkarsh.dao;

import com.utkarsh.entity.Users;
import com.utkarsh.exceptions.UsersException;

public interface UsersDAO {

    public boolean registerUser(Users objUser) throws UsersException;
    public Users getUserDetails(String userName) throws UsersException;
}
