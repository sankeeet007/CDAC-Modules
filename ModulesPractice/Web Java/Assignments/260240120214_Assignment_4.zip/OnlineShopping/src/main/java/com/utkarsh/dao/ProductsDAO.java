package com.utkarsh.dao;

import com.utkarsh.entity.Products;
import com.utkarsh.exceptions.CategoryException;
import com.utkarsh.exceptions.ProductException;

public interface ProductsDAO {

    public boolean addProduct(Products objProduct) throws ProductException;
    public Products getProductDetails(int productId) throws ProductException;
    public boolean deleteProduct(int productId) throws ProductException;
}