package com.utkarsh.servlets;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/Logout")
public class LogOut extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession(false);
		if (session != null) {
			session.invalidate();
		}

		Cookie userCookie = new Cookie("userName", "");
		userCookie.setMaxAge(0);
		userCookie.setPath("/");
		response.addCookie(userCookie);

		Cookie roleCookie = new Cookie("role", "");
		roleCookie.setMaxAge(0);
		roleCookie.setPath("/");
		response.addCookie(roleCookie);

		response.sendRedirect("login.html");
	}
}