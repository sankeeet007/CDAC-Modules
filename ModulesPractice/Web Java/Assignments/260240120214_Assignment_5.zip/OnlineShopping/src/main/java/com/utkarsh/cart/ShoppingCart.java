package com.utkarsh.cart;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.utkarsh.entity.Products;

public class ShoppingCart implements Cart {

	private ArrayList<Products> allItems = new ArrayList<>();

	@Override
	public void addToCart(Products objProduct) {
		allItems.add(objProduct);
	}

	@Override
	public Iterator<Products> listCart() {
		return allItems.iterator();
	}

	@Override
	public List<Products> getCartItems() {
		return allItems;
	}

	@Override
	public float getTotalPrice() {
		float total = 0;
		for (Products p : allItems) {
			total += p.getProductPrice();
		}
		return total;
	}
}