package com.utkarsh.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/OrderConfirmation")
public class OrderConfirmation extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession(false);
		String userName = (String) session.getAttribute("userName");
		String orderId = request.getParameter("orderId");

		PrintWriter out = response.getWriter();
		out.println("<html><body>");
		out.println("<h2>Order Placed Successfully!</h2>");
		out.println("<p>Thank you, <b>" + userName + "</b>!</p>");
		out.println("<p>Your Order ID is : <b>" + orderId + "</b></p>");
		out.println("<br/><a href='Category'>Continue Shopping</a>");
		out.println("&nbsp;&nbsp;<a href='Logout'>Logout</a>");
		out.println("</body></html>");
	}
}