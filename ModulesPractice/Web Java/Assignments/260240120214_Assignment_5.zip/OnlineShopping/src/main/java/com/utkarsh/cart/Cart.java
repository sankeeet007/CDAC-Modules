package com.utkarsh.cart;

import java.util.Iterator;
import java.util.List;

import com.utkarsh.entity.Products;

public interface Cart {
	void addToCart(Products objProduct);

	Iterator<Products> listCart();

	List<Products> getCartItems();

	float getTotalPrice();
}