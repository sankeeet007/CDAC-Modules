package com.utkarsh.dao;

import com.utkarsh.entity.Order;
import com.utkarsh.entity.Payment;
import com.utkarsh.entity.Products;
import java.util.List;

public interface OrderDAO {
	int placeOrder(Order order, List<Products> items) throws Exception;
	boolean savePayment(Payment payment) throws Exception;
}