package com.utkarsh.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.utkarsh.entity.Products;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/Products")
public class Product extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null) {
            response.sendRedirect("login.html");
            return;
        }

        String tmp = request.getParameter("categoryId");
        int categoryId = Integer.parseInt(tmp);

        List<Products> productList = new ArrayList<>();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection connection = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/cdac", "cdac", "cdac");
                 PreparedStatement ps = connection
                    .prepareStatement("SELECT * FROM products WHERE categoryId = ?")) {

                ps.setInt(1, categoryId);

                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        Products p = new Products();
                        p.setProductId(rs.getInt("productId"));
                        p.setProductName(rs.getString("productName"));
                        p.setProductDescription(rs.getString("productDescription"));
                        p.setProductPrice(rs.getDouble("productPrice"));
                        p.setCategoryId(categoryId);
                        productList.add(p);
                    }
                }
            } catch (SQLException e) {
                request.setAttribute("dbError", e.getMessage());
            }
        } catch (ClassNotFoundException e) {
            request.setAttribute("dbError", "Driver not found: " + e.getMessage());
        }

        // Pass data to JSP
        request.setAttribute("productList", productList);
        request.setAttribute("categoryId", categoryId);
        request.getRequestDispatcher("products.jsp").forward(request, response);
    }
}