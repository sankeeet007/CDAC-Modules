package com.utkarsh.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

import com.utkarsh.cart.Cart;
import com.utkarsh.dao.OrderDAO;
import com.utkarsh.dao.OrderDAOImpl;
import com.utkarsh.entity.Order;
import com.utkarsh.entity.Payment;
import com.utkarsh.entity.Products;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebInitParam;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet(initParams = { @WebInitParam(name = "driverClass", value = "com.mysql.cj.jdbc.Driver"),
		@WebInitParam(name = "dbUrl", value = "jdbc:mysql://localhost:3306/cdac"),
		@WebInitParam(name = "dbUser", value = "cdac"),
		@WebInitParam(name = "dbPassword", value = "cdac") }, urlPatterns = { "/Checkout" })
public class Checkout extends HttpServlet {

	private static final long serialVersionUID = 1L;

	private Connection connection;

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		try {
			Class.forName(config.getInitParameter("driverClass"));
			connection = DriverManager.getConnection(config.getInitParameter("dbUrl"),
					config.getInitParameter("dbUser"), config.getInitParameter("dbPassword"));
		} catch (Exception e) {
			throw new ServletException("DB init failed: " + e.getMessage(), e);
		}
	}

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession(false);
		if (session == null || session.getAttribute("userName") == null) {
			response.sendRedirect(request.getContextPath() + "/login.html");
			return;
		}

		super.service(request, response);
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.sendRedirect(request.getContextPath() + "/checkout.html");
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession(false);
		String userName = (String) session.getAttribute("userName");
		Cart objCart = (Cart) session.getAttribute("cart");

		if (objCart == null) {
			response.sendRedirect(request.getContextPath() + "/Category");
			return;
		}

		List<Products> items = objCart.getCartItems();
		float total = 0;
		for (Products p : items) {
			total += p.getProductPrice();
		}

		String cardHolder = request.getParameter("cardHolder");
		String cardNumber = request.getParameter("cardNumber");
		String expiryDate = request.getParameter("expiryDate");

		try {
			OrderDAO orderDAO = new OrderDAOImpl(connection);

			Order order = new Order();
			order.setUserName(userName);
			order.setTotalAmount(total);

			int orderId = orderDAO.placeOrder(order, items);

			Payment payment = new Payment();
			payment.setOrderId(orderId);
			payment.setCardHolder(cardHolder);
			payment.setCardNumber(cardNumber);
			payment.setExpiryDate(expiryDate);
			payment.setAmount(total);

			orderDAO.savePayment(payment);

			session.removeAttribute("cart");

			// ✅ Redirect to Servlet, NOT directly to JSP
			response.sendRedirect(request.getContextPath() + "/OrderConfirmation?orderId=" + orderId);

		} catch (Exception e) {
			e.printStackTrace();
			response.getWriter().println("Checkout failed: " + e.getMessage());
		}
	}

	@Override
	public void destroy() {
		if (connection != null) {
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		super.destroy();
	}
}