package com.utkarsh.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.utkarsh.entity.Order;
import com.utkarsh.entity.Payment;
import com.utkarsh.entity.Products;

public class OrderDAOImpl implements OrderDAO {

	private Connection connection;

	public OrderDAOImpl(Connection connection) {
		this.connection = connection;
	}

	@Override
	public int placeOrder(Order order, List<Products> items) throws Exception {
		String orderQuery = "INSERT INTO orders (userName, totalAmount, status) VALUES (?, ?, ?)";

		try (PreparedStatement ps = connection.prepareStatement(orderQuery, PreparedStatement.RETURN_GENERATED_KEYS)) {

			ps.setString(1, order.getUserName());
			ps.setFloat(2, order.getTotalAmount());
			ps.setString(3, "PLACED");
			ps.executeUpdate();

			ResultSet rs = ps.getGeneratedKeys();
			int orderId = 0;
			if (rs.next()) {
				orderId = rs.getInt(1);
			}

			String itemQuery = "INSERT INTO orderitems (orderId, productId, categoryId, price) VALUES (?, ?, ?, ?)";
			try (PreparedStatement psItem = connection.prepareStatement(itemQuery)) {
				for (Products p : items) {
					psItem.setInt(1, orderId);
					psItem.setInt(2, p.getProductId());
					psItem.setInt(3, p.getCategoryId());
					psItem.setDouble(4, p.getProductPrice());
					psItem.addBatch();
				}
				psItem.executeBatch();
			}

			return orderId;
		}
	}

	@Override
	public boolean savePayment(Payment payment) throws Exception {
		String query = "INSERT INTO payments (orderId, cardHolder, cardNumber, expiryDate, amount) VALUES (?, ?, ?, ?, ?)";

		try (PreparedStatement ps = connection.prepareStatement(query)) {
			ps.setInt(1, payment.getOrderId());
			ps.setString(2, payment.getCardHolder());
			ps.setString(3, payment.getCardNumber());
			ps.setString(4, payment.getExpiryDate());
			ps.setFloat(5, payment.getAmount());
			return ps.executeUpdate() > 0;
		}
	}
}