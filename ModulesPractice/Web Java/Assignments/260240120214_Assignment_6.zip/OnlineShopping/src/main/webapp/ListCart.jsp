<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="com.utkarsh.cart.Cart" %>
<%@ page import="com.utkarsh.entity.Products" %>
<%@ page import="java.util.Iterator" %>

<%
    // Session guard
    HttpSession objSession = request.getSession(false);
    if (objSession == null) {
        response.sendRedirect("login.html");
        return;
    }
    Cart objCart = (Cart) objSession.getAttribute("cart");
    String userName = (String) objSession.getAttribute("userName");
%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Your Cart</title>
</head>
<body>

<h2>Welcome, <%= userName %></h2>
<a href="Logout">Logout</a>

<%
    if (objCart == null) {
%>
    <p>Cart is empty</p>
<%
    } else {
        double total = 0.0;
        Iterator<Products> iter = objCart.listCart();
%>
    <table border="1">
        <tr>
            <th>Category ID</th>
            <th>Product ID</th>
            <th>Price</th>
        </tr>
        <%
            while (iter.hasNext()) {
                Products p = iter.next();
                total += p.getProductPrice();
        %>
        <tr>
            <td><%= p.getCategoryId() %></td>
            <td><%= p.getProductId() %></td>
            <td><%= p.getProductPrice() %></td>
        </tr>
        <%
            }
        %>
    </table>
    <h3>Total: <%= total %></h3>
    <a href="Checkout">Checkout</a> |
    <a href="Category">Continue Shopping</a>
<%
    }
%>

</body>
</html>