<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>

<%
    HttpSession objSession = request.getSession(false);
    if (objSession == null) {
        response.sendRedirect("login.html");
        return;
    }
    String userName = (String) objSession.getAttribute("userName");
    String orderId  = request.getParameter("orderId");
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Order Confirmation</title>
</head>
<body>
    <h2>Order Placed Successfully!</h2>
    <p>Thank you, <b><%= userName %></b>!</p>
    <p>Your Order ID is: <b><%= orderId %></b></p>

    <br/>
    <a href="Category">Continue Shopping</a>
    <a href="Logout">Logout</a>

</body>
</html>