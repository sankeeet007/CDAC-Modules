<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.util.List" %>
<%@ page import="com.utkarsh.entity.Products" %>

<%
    String dbError         = (String) request.getAttribute("dbError");
    List<Products> productList = (List<Products>) request.getAttribute("productList");
    int categoryId         = (Integer) request.getAttribute("categoryId");
    String userName        = (String) session.getAttribute("userName");
%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Products</title>
</head>
<body>

    Welcome <b><%= userName %></b><br/>
    <a href="Logout">Logout</a>
    &nbsp;|&nbsp;
    <a href="Category">Back</a>
    <br/><br/>

    <% if (dbError != null) { %>
        <p style="color:red;">Database error: <%= dbError %></p>
    <% } else if (productList == null || productList.isEmpty()) { %>
        <p>No products found for this category.</p>
    <% } else { %>
        <table border="1">
            <tr>
                <th>Name</th>
                <th>Description</th>
                <th>Price</th>
                <th>Action</th>
            </tr>
            <% for (Products p : productList) { %>
            <tr>
                <td><%= p.getProductName() %></td>
                <td><%= p.getProductDescription() %></td>
                <td><%= p.getProductPrice() %></td>
                <td><a href="AddCart?categoryId=<%= categoryId %>&productId=<%= p.getProductId() %>&price=<%= p.getProductPrice() %>">Add to Cart</a></td>
            </tr>
            <% } %>
        </table>
    <% } %>

</body>
</html>