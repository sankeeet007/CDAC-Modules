package com.utkarsh.Question2;

import java.sql.Connection;
import java.util.Scanner;

public class Entry {

    public static void main(String[] args) {
        try (
            Connection con = DBUtil.getConnection();
            Scanner sc = new Scanner(System.in)
        ) {
            System.out.println("Database Connected Successfully!");

            int choice;
            do {
                System.out.println("\n===== MAIN MENU =====");
                System.out.println("1. Create Table");
                System.out.println("2. Display Columns of a Table");
                System.out.println("3. Exit");
                System.out.print("Enter choice: ");
                choice = Integer.parseInt(sc.nextLine());

                switch (choice) {
                    case 1:
                        TableService.createTable(sc, con);
                        break;
                    case 2:
                        TableService.displayColumns(sc, con);
                        break;
                    case 3:
                        System.out.println("Exiting...");
                        break;
                    default:
                        System.out.println("Wrong choice! Try again.");
                }

            } while (choice != 3);

        } catch (Exception e) {
            System.out.println("Error occurred!");
            e.printStackTrace();
        }
    }
}