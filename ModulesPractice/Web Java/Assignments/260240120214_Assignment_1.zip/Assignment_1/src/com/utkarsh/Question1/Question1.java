package com.utkarsh.Question1;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;
import java.util.Scanner;

public class Question1 {

    public static void registerUser(Scanner sc, Connection con) throws Exception {
        System.out.print("Enter Username : ");
        String username = sc.nextLine();

        System.out.print("Enter Password : ");
        String password = sc.nextLine();

        System.out.print("Enter Name     : ");
        String name = sc.nextLine();

        System.out.print("Enter Email    : ");
        String email = sc.nextLine();

        System.out.print("Enter City     : ");
        String city = sc.nextLine();

        String sql = "INSERT INTO users (username, password, name, email, city) VALUES (?, ?, ?, ?, ?)";

        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, password);
            ps.setString(3, name);
            ps.setString(4, email);
            ps.setString(5, city);

            int rows = ps.executeUpdate();
            System.out.println(rows + " user inserted successfully!");
        }
    }

    public static void listUserBasedOnCity(Scanner sc, Connection con) throws Exception {
        System.out.print("Enter City : ");
        String city = sc.nextLine();

        String sql = "SELECT * FROM users WHERE city = ?";

        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, city);

            try (ResultSet rs = ps.executeQuery()) {
                boolean found = false;

                while (rs.next()) {
                    found = true;
                    System.out.println("----------------------------");
                    System.out.println("Username : " + rs.getString("username"));
                    System.out.println("Password : " + rs.getString("password"));
                    System.out.println("Name     : " + rs.getString("name"));
                    System.out.println("Email    : " + rs.getString("email"));
                    System.out.println("City     : " + rs.getString("city"));
                }

                if (!found) {
                    System.out.println("No users found for city: " + city);
                }
            }
        }
    }

    public static void updatePassword(Scanner sc, Connection con) throws Exception {
        System.out.print("Enter Username : ");
        String username = sc.nextLine();

        System.out.print("Enter New Password : ");
        String password = sc.nextLine();

        String sql = "UPDATE users SET password = ? WHERE username = ?";

        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, password);
            ps.setString(2, username);

            int rows = ps.executeUpdate();

            if (rows > 0) {
                System.out.println("Password updated successfully!");
            } else {
                System.out.println("User not found. No changes made.");
            }
        }
    }

    public static void displayInfoBasedOnUserName(Scanner sc, Connection con) throws Exception {
        System.out.print("Enter Name : ");
        String name = sc.nextLine();

        String sql = "SELECT * FROM users WHERE name = ?";

        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, name);

            try (ResultSet rs = ps.executeQuery()) {
                boolean found = false;

                while (rs.next()) {
                    found = true;
                    System.out.println("----------------------------");
                    System.out.println("Username : " + rs.getString("username"));
                    System.out.println("Password : " + rs.getString("password"));
                    System.out.println("Name     : " + rs.getString("name"));
                    System.out.println("Email    : " + rs.getString("email"));
                    System.out.println("City     : " + rs.getString("city"));
                }

                if (!found) {
                    System.out.println("No user found with name: " + name);
                }
            }
        }
    }

    public static void main(String[] args) {

        Properties properties = new Properties();
        try {
            properties.load(new FileInputStream("db.properties"));
        } catch (Exception e) {
            System.out.println("Failed to load db.properties!");
            e.printStackTrace();
            return;
        }

        String url = properties.getProperty("jdbc.url");
        String user = properties.getProperty("jdbc.username");
        String password = properties.getProperty("jdbc.password");
        String driver = properties.getProperty("jdbc.driver");

        try {
            Class.forName(driver);
        } catch (Exception e) {
            System.out.println("Driver loading failed!");
            e.printStackTrace();
            return;
        }

        try (
            Connection con = DriverManager.getConnection(url, user, password);
            Scanner sc = new Scanner(System.in)
        ) {
            System.out.println("Connection Successful!");

            int choice;
            do {
                System.out.println("\n===== MENU =====");
                System.out.println("1. Register a User");
                System.out.println("2. List All Users based on City");
                System.out.println("3. Update Password of a User");
                System.out.println("4. Display user information based on Name");
                System.out.println("5. Exit");
                System.out.print("Enter choice : ");

                choice = Integer.parseInt(sc.nextLine());

                switch (choice) {
                    case 1:
                        registerUser(sc, con);
                        break;
                    case 2:
                        listUserBasedOnCity(sc, con);
                        break;
                    case 3:
                        updatePassword(sc, con);
                        break;
                    case 4:
                        displayInfoBasedOnUserName(sc, con);
                        break;
                    case 5:
                        System.out.println("Exiting...");
                        break;
                    default:
                        System.out.println("Invalid choice! Try again.");
                }

            } while (choice != 5);

        } catch (Exception e) {
            System.out.println("DB Operation Failed!");
            e.printStackTrace();
        }
    }
}