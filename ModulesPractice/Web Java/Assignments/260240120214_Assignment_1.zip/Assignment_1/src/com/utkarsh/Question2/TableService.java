package com.utkarsh.Question2;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class TableService {

    public static void createTable(Scanner sc, Connection con) throws Exception {
        System.out.print("Enter table name: ");
        String tableName = sc.nextLine();

        List<String> columns = new ArrayList<>();
        String primaryKey = null;

        int choice;
        do {
            System.out.println("\n--- Create Table Menu ---");
            System.out.println("1. Add Column");
            System.out.println("2. Set Primary Key");
            System.out.println("3. Save Table");
            System.out.print("Enter choice: ");
            choice = Integer.parseInt(sc.nextLine());

            switch (choice) {
                case 1:
                    System.out.print("Enter column name: ");
                    String columnName = sc.nextLine();

                    System.out.println("Select datatype:");
                    System.out.println("1. VARCHAR(50)");
                    System.out.println("2. INT");
                    System.out.println("3. FLOAT");
                    System.out.print("Enter option: ");
                    int typeChoice = Integer.parseInt(sc.nextLine());

                    String dataType = "";
                    switch (typeChoice) {
                        case 1:
                            dataType = "VARCHAR(50)";
                            break;
                        case 2:
                            dataType = "INT";
                            break;
                        case 3:
                            dataType = "FLOAT";
                            break;
                        default:
                            System.out.println("Invalid datatype option!");
                            continue;
                    }

                    columns.add(columnName + " " + dataType);
                    System.out.println("Column added successfully!");
                    break;

                case 2:
                    if (columns.isEmpty()) {
                        System.out.println("Add columns first!");
                        break;
                    }

                    System.out.println("Available columns:");
                    for (int i = 0; i < columns.size(); i++) {
                        String colOnly = columns.get(i).split(" ")[0];
                        System.out.println((i + 1) + ". " + colOnly);
                    }

                    System.out.print("Select column number for primary key: ");
                    int pkChoice = Integer.parseInt(sc.nextLine());

                    if (pkChoice >= 1 && pkChoice <= columns.size()) {
                        primaryKey = columns.get(pkChoice - 1).split(" ")[0];
                        System.out.println("Primary key set on: " + primaryKey);
                    } else {
                        System.out.println("Invalid choice!");
                    }
                    break;

                case 3:
                    if (columns.isEmpty()) {
                        System.out.println("Cannot create table without columns!");
                        break;
                    }

                    StringBuilder query = new StringBuilder();
                    query.append("CREATE TABLE ").append(tableName).append(" (");

                    for (int i = 0; i < columns.size(); i++) {
                        query.append(columns.get(i));
                        if (i != columns.size() - 1 || primaryKey != null) {
                            query.append(", ");
                        }
                    }

                    if (primaryKey != null) {
                        query.append("PRIMARY KEY(").append(primaryKey).append(")");
                    }

                    query.append(")");

                    try (Statement st = con.createStatement()) {
                        st.executeUpdate(query.toString());
                        System.out.println("Table created successfully!");
                        System.out.println("SQL => " + query);
                    }
                    break;

                default:
                    System.out.println("Invalid choice!");
            }

        } while (choice != 3);
    }

    public static void displayColumns(Scanner sc, Connection con) throws Exception {
        System.out.print("Enter table name: ");
        String tableName = sc.nextLine();

        DatabaseMetaData metaData = con.getMetaData();
        ResultSet rs = metaData.getColumns(null, null, tableName, null);

        boolean found = false;
        System.out.println("Columns in table " + tableName + ":");

        while (rs.next()) {
            found = true;
            System.out.println(rs.getString("COLUMN_NAME"));
        }

        if (!found) {
            System.out.println("Table not found or no columns exist.");
        }

        rs.close();
    }
}
