package com.utkarsh.DAO;


public interface UsersDAO {

    public boolean registerUser(Users objUser) throws UsersException;

    public Users getUserDetails(String userName) throws UsersException;

    public boolean removeUser(String userName) throws UsersException;
}
