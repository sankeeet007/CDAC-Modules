package com.utkarsh.DAO.Test;

import com.utkarsh.DAO.Users;
import com.utkarsh.DAO.UsersDAO;
import com.utkarsh.DAO.UsersDAOImpl;
import com.utkarsh.DAO.UsersException;

public class DAOTest {

    public static void main(String[] args) {
        try {
            UsersDAO usersDAO = new UsersDAOImpl();

            Users newUser = new Users();
            newUser.setUserName("cdac1");
            newUser.setPassword("pass123");
            newUser.setName("Utkarsh");
            newUser.setEmail("utkarsh@cdac.in");
            newUser.setCity("Pune");

            boolean registered = usersDAO.registerUser(newUser);
            System.out.println("Registered: " + registered);

           
            Users objUser = usersDAO.getUserDetails("cdac1");

            if (objUser != null) {
                System.out.println("Name  : " + objUser.getName());
                System.out.println("Email : " + objUser.getEmail());
                System.out.println("City  : " + objUser.getCity());
            } else {
                System.out.println("User not found in DB!");
            }

            boolean removed = usersDAO.removeUser("cdac1");
            System.out.println("Removed: " + removed);

        } catch (UsersException e) {
            e.printStackTrace();
        }
    }
}