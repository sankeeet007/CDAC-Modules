package com.utkarsh;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.Scanner;

public class TestingStoredProcedure {

    public static void main(String[] args) {
        try {
            Properties props = new Properties();
            props.load(new FileInputStream("application.properties"));

            String url  = props.getProperty("db.url");
            String user = props.getProperty("db.username");
            String pwd  = props.getProperty("db.password");

            try (Connection connection = DriverManager.getConnection(url, user, pwd);
                 Statement stRecordCount = connection.createStatement();
                 Scanner scanner = new Scanner(System.in)) {

                boolean status = stRecordCount.execute("call GetRecordCount()");

                while (status) {
                    try (ResultSet result = stRecordCount.getResultSet()) {
                        if (result.next()) {
                            System.out.println(result.getInt(1));
                        }
                    }
                    status = stRecordCount.getMoreResults();
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
