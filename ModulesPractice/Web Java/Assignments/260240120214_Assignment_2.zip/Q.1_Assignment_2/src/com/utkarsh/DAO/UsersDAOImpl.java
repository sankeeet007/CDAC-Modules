package com.utkarsh.DAO;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

public class UsersDAOImpl implements UsersDAO {

    Connection connection;
    PreparedStatement psRegisterUser;
    PreparedStatement psUserDetails;
    PreparedStatement psRemoveUser;

    public UsersDAOImpl() throws UsersException {
        try {
            Properties props = new Properties();
            props.load(new FileInputStream("application.properties"));

            String url  = props.getProperty("db.url");
            String user = props.getProperty("db.username");
            String pwd  = props.getProperty("db.password");
            String driver = props.getProperty("db.driver");

            Class.forName(driver);
            connection = DriverManager.getConnection(url, user, pwd);

           
            psRegisterUser = connection.prepareStatement(
                "INSERT INTO users (username, password, name, email, city) VALUES (?, ?, ?, ?, ?)");

          
            psUserDetails = connection.prepareStatement(
                "SELECT * FROM users WHERE username = ?");

            psRemoveUser = connection.prepareStatement(
                "DELETE FROM users WHERE username = ?");

        } catch (Exception e) {
            throw new UsersException("Initialization failed : " + e.getMessage());
        }
    }

    @Override
    public boolean registerUser(Users objUser) throws UsersException {
        try {
            psRegisterUser.clearParameters();

            psRegisterUser.setString(1, objUser.getUserName());
            psRegisterUser.setString(2, objUser.getPassword());
            psRegisterUser.setString(3, objUser.getName());
            psRegisterUser.setString(4, objUser.getEmail());
            psRegisterUser.setString(5, objUser.getCity()); 

            psRegisterUser.executeUpdate();
            return true;

        } catch (SQLException e) {
            throw new UsersException("Failed to register user : " + e.getMessage());
        }
    }

    @Override
    public Users getUserDetails(String userName) throws UsersException {
        try {
            psUserDetails.clearParameters();
            psUserDetails.setString(1, userName);

            try (ResultSet result = psUserDetails.executeQuery()) {
                if (result.next()) {
                    Users objUser = new Users();
                    objUser.setUserName(result.getString("username")); // FIX 4: use column names not index
                    objUser.setPassword(result.getString("password"));
                    objUser.setName(result.getString("name"));
                    objUser.setEmail(result.getString("email"));
                    objUser.setCity(result.getString("city")); // FIX 5: city was missing
                    return objUser;
                }
            }

        } catch (SQLException e) {
            throw new UsersException("Error fetching user : " + e.getMessage());
        }

        return null;
    }

    @Override
    public boolean removeUser(String userName) throws UsersException {
        try {
            psRemoveUser.clearParameters();
            psRemoveUser.setString(1, userName);

            int rows = psRemoveUser.executeUpdate();
            return rows > 0;

        } catch (SQLException e) {
            throw new UsersException("Failed to remove user : " + e.getMessage());
        }
    }
}