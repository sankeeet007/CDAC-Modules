package com.utkarsh.Assignment_7;

import java.util.Scanner;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.utkarsh.entities.Category;

public class App {

	public static void main(String[] args) {

		Configuration hibernateConfiguration = new Configuration();
		hibernateConfiguration.addAnnotatedClass(Category.class);
		hibernateConfiguration.configure();

		SessionFactory sessionFactory = hibernateConfiguration.buildSessionFactory();

		try (Session hibernateSession = sessionFactory.openSession();

				Scanner scanner = new Scanner(System.in)) {

			System.out.println("Enter the Category ID:");
			int categoryId = scanner.nextInt();
			scanner.nextLine();

			System.out.println("Enter the Category Name:");
			String categoryName = scanner.nextLine();

			System.out.println("Enter the Category Description:");
			String categoryDescription = scanner.nextLine();

			System.out.println("Enter the Category Image URL:");
			String categoryImageUrl = scanner.nextLine();

			Category category = new Category();

			category.setCategoryId(categoryId);
			category.setCategoryName(categoryName);
			category.setCategoryDescription(categoryDescription);
			category.setCategoryImageUrl(categoryImageUrl);

			Transaction transaction = hibernateSession.beginTransaction();

			hibernateSession.persist(category);

			transaction.commit();

			System.out.println("Category Record Saved");

		} catch (HibernateException he) {
			he.printStackTrace();
		}
	}
}